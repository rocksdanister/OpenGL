

struct path
{
int a[4][2];
};

extern int i,r,j,k,n,q,t,sx,sy,easy;
extern double p1,queuedMilliseconds,prev0;
void init();
void keyboard(int,int,int);
void draw2();
