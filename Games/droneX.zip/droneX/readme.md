Work in progress project. 

![Alt text](/WorkOut/temp_files/dronx.jpg?raw=true "droneX")

Requirement: SOIL image loader, `sudo apt-get install libsoil-dev libsoil1`

Changelog:

1. Added continuous scrolling background.
2. Partial object collision detected(somewhat xD).
3. Fixed cloud generation algorithm.
4. Displaylist implemented ( old code is: draw_backup.cpp ).
5. Added Score board.
6. Bounds set.

Needs to be done:

1. Optimising collision detection.
2. Optimising rendering resolution.
3. Further optimising performance.
4. Final Score display format.
