extern double queuedMilliseconds,prev0,fps,responseTime,score;
extern int movementY,movementX, speed;

void init();
void processSpecialKeys(int , int , int );
void mixedStepLoop();
void draw();
void update();
