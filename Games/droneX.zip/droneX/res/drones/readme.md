drone textures
