obstacle textures
