
extern double responseTime,fps,prev;

void processMenuEvents(int options);
void createGLUTMenus();
void draw();
void update();
void mixedStepLoop();



