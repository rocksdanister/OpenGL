#include <GL/glut.h>
#include <drone.h>


void mixedStepLoop()
{
    double now = glutGet(GLUT_ELAPSED_TIME);
    double timeElapsedMs =(now-prev0);
    queuedMilliseconds += timeElapsedMs ;
    while(queuedMilliseconds >= responseTime) 
    {
        if(flag==1)
        {
        update();
        }
        queuedMilliseconds -= responseTime;
        glutPostRedisplay();
    }
    prev0=now;
}

