extern double queuedMilliseconds,prev0,fps,responseTime;
extern int movementY,movementX;

void init();
void processSpecialKeys(int , int , int );
void mixedStepLoop();
void draw();
void update();
