animation test builds
