
extern float lx,lz,x,z,angle;
extern double p,q,r;
void draw();
void processNormalKeys(unsigned char,int,int);
void processSpecialKeys(int,int,int);
